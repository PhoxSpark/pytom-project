# pytom-project
Project for collect atom data from PDB database for the BSC, made it with Python.
